var fs = require('fs');
var through = require('through2');
var path = require('path');
var gutil = require('gulp-util');
var File = gutil.File;
var config = require('../config');
var projectConfig = config.projectConfig;

module.exports = function (template, opt) {
    opt = opt || {};
    var stripPrefix = opt.stripPrefix || '';
    var argv = opt.argv || {};
    var isMinify = opt.argv.minify || false;
    var fileNames = [];
    return through.obj(function (file, enc, cb) {
        var jsFile = path.relative(stripPrefix, file.relative);
        fileNames.push(jsFile);
        cb();
    }, function (cb) {
        var contents = fs.readFileSync(template, 'utf-8');
        contents = replaceEngineFiles(contents, argv.noVersionTag, isMinify);
        contents = replaceModuleFiles(contents, argv.noVersionTag, isMinify);
        contents = replaceGameFiles(contents, fileNames, argv.noVersionTag);

        var file = new File();
        file.contents = Buffer.from(contents);
        file.path = path.basename(template);
        this.push(file);

        contents = fs.readFileSync(template, 'utf-8');
        contents = replaceGameFiles(contents, ["code.js"], argv.noVersionTag);

        file = new File();
        file.contents = Buffer.from(contents);
        file.path = "code-" + path.basename(template);
        this.push(file);
        cb();
    });
};

function replaceEngineFiles(contents, noVersionTag, isMinify) {
    var moduleFiles = projectConfig.getModuleFilesByType('engine', isMinify);
    var path = projectConfig.getFramePatch();
    // if (isMinify) moduleFiles = moduleFiles.map(file => path + file);
    if (isMinify) moduleFiles = [path + "libs/laya/engine.js"];
    var version = noVersionTag ? '' : projectConfig.getEngineVersion();
    return replaceJs(contents, '<!--engine-file-start-->', '<!--engine-file-end-->',
        moduleFiles, version, 4);
}

function replaceModuleFiles(contents, noVersionTag, isMinify) {
    var moduleFiles = projectConfig.getModuleFilesByType('game');
    var path = projectConfig.getFramePatch();
    var version = noVersionTag ? '' : projectConfig.getCiteVersion();
    if (isMinify) moduleFiles = moduleFiles.map(file => path + file);
    return replaceJs(contents, '<!--module-file-start-->', '<!--module-file-start-->',
        moduleFiles, version, 4);
}

function replaceGameFiles(contents, files, noVersionTag) {
    var jsFiles = files.concat();
    jsFiles.unshift('app.js');
    var version = noVersionTag ? '' : projectConfig.getGameVersion();
    return replaceJs(contents, '<!--game-file-start-->', '<!--game-file-end-->',
        jsFiles, version, 4);
}

function replaceJs(contents, startTag, endTag, jsFiles, version, indent) {
    var spaces = ' '.repeat(indent);
    var files = '\n';
    var versionTag = version ? '?v=' + version : '';
    jsFiles.forEach(jsFile => {
        files += spaces + `<script src="${jsFile}${versionTag}"></script>\n`;
    });
    files += spaces;
    var re = new RegExp('(' + startTag + ')(.|[\\r\\n])*(' + endTag + ')');
    return contents.replace(re, '$1' + files + '$3');
}
