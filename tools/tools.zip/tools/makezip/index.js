var fs = require('fs-extra');
var path = require('path')
var _ = require('lodash');
var config = require('../config');
var glob = require('glob');
var gulputil = require('gulp-util');

function zipFilesForDolphin(zipPath) {
    gulputil.log('开始压缩为GCloud Dolphin资源更新文件...');
    return new Promise((resolve, reject) => {
        let archive = require('archiver')('zip');
        let fileName = path.basename(zipPath);
        
        let outFilePath = path.join(path.dirname(zipPath), 'dolphin-' + fileName);
        let output = fs.createWriteStream(outFilePath);
        output.on('close', () => {
            gulputil.log('压缩Dolphin资源更新文件成功,压缩文件为: ' + outFilePath);
            resolve(outFilePath)
        });
        archive.on('error', err => reject(err));
        archive.pipe(output);
        archive.file(zipPath,{name: "patch/"+fileName});
        archive.finalize();
    })
}

function makeZip(srcPath, subPath) {
    if(!srcPath || srcPath.length == 0) {
        gulputil.log('--path 路径 指定本次全量版本的路径');
        return;
    }
    if(!subPath || subPath.length == 0) {
        gulputil.log('--subpath 子路径 指定res/assets下需要压缩的子文件夹：如：item.d');
        return;
    }

    gulputil.log(`开始压缩子路径${subPath}下文件到压缩包...`)
    var startTime = Date.now();
    
    var destPath = path.join(path.dirname(srcPath), "zipfile");
    if(!fs.existsSync(destPath)) //zip文件夹不存在时自动创建
        fs.mkdir(destPath);

    if(subPath == "*") { //压缩所有res/assets目录下文件
        var dirs = glob.sync(path.join(config.packedAssetsPath, '*'), { cwd: srcPath });
        if(dirs.length > 0) {
            var fileName = path.basename(config.packedAssetsPath) + '.zip';
    
            let archive = require('archiver')('zip');
            let outFilePath = path.join(destPath, fileName);
            let output = fs.createWriteStream(outFilePath);
            output.on('close', () => {
                gulputil.log('压缩子路径成功,压缩文件为: ' + outFilePath);
                zipFilesForDolphin(outFilePath);
            });
            archive.on('error', err =>reject(err));
            archive.pipe(output);
            dirs.forEach(dir => {
                gulputil.log('压缩子路径 ' + dir);
                archive.directory(path.join(srcPath,dir),dir);
            })
            archive.finalize();
        }
    }
    else {
        var fileName = path.basename(subPath) + '.zip';
        var relativePath = path.join(config.packedAssetsPath,subPath);

        let archive = require('archiver')('zip');
        let outFilePath = path.join(destPath, fileName);
        let output = fs.createWriteStream(outFilePath);
        output.on('close', () => {
            gulputil.log('压缩子路径成功,压缩文件为: ' + outFilePath);
            zipFilesForDolphin(outFilePath);
        });
        archive.on('error', err => reject(err));
        archive.pipe(output);
        archive.directory(path.join(srcPath,relativePath),relativePath);
        archive.finalize();
    }
}

module.exports = makeZip;

if (require.main == module) {
    var argv = require('yargs').help('h')
        .option('path', { alias: 'p', describe: '指定本次全量版本的路径' })
        .option('subpath', { describe: '指定res/assets下需要压缩的子路径：如：item.d' })
        .demand(['path', 'subpath'])
        .argv;
    makeZip(path.normalize(argv.path), path.normalize(argv.subpath));
}
