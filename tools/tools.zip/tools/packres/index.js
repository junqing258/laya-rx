var fs = require('fs-extra');
var path = require('path');
var crypto = require('crypto');
var config = require('../config');
var PromisePool = require('es6-promise-pool');
var ProgressBar = require('progress');
var settings = require(path.join(config.projectPath, config.settingsFile));
var resmanager = require('../resmanager');
var CacheManager = require('./CacheManager');
var getTransformer = require('./transform.js');
var _ = require('lodash');

// 检查是否所有应该合图的资源都完成合图了
function validateAtlas(atlasMap, resGroup) {
    var result = true;
    _.each(resGroup, (files, group) => {
        _.each(files, file => {
            if (!atlasMap[file]) {
                console.error(`${file} is not packed in atlas`);
                result = false;
            }
        })
    });
    return result;
}

function copyOthers(cache, isMd5) {
    var others = [];
    if (settings.metaResources) others = settings.metaResources.concat();
    return new PromisePool(() => {
        if (others.length == 0)
            return null;
        if (isMd5) {
            if (others.length == 0)
                return null;
            var file1 = others.shift();
            return doTransform(file1, cache, isMd5, false);
        }
        let file = others.shift();
        var srcFile = path.join(config.projectPath, config.resourcePath, file);
        var destFile = path.join(config.projectPath, config.packedResPath, file);
        return fs.exists(srcFile).then(() => {
            fs.copy(srcFile, destFile);
        });
    }, 3).start();
}

function doTransform(file, cache, isMd5, isSource) {
    var isSkipTransform = settings.transformExcludes.indexOf(file) >= 0;
    var transformer = getTransformer(isSkipTransform ? '' : path.extname(file));
    var filePath = path.join(config.projectPath, isSource ? config.assetsPath : config.resourcePath, file);
    var ext = path.extname(file);
    return fs.readFile(filePath).then(buf => {
        var md5 = getMd5(buf);
        if (cache.useCache(file, md5, isSkipTransform)) // 已经有缓存，不需要处理
            return null;
        cache.setSourceMd5(file, md5);
        return transformer(buf);
    }).then(buf => {
        if (buf == null) // buf为null时不需要处理
            return;
        var md5 = getMd5(buf);
        var states = fs.statSync(filePath);
        var path1 = path.dirname(file) + "/";
        var noPathName;
        var pngSource;
        if (ext == ".json" || ext == ".st" || ext == ".atlas" || ext == ".sk") {
            pngSource = file.replace(ext, ".png");
        }
        if (pngSource) noPathName = cache.getDestFilesMd5(pngSource);
        if (!noPathName) noPathName = md5.slice(0, 5) + states.size;
        var md5Name = path1 + noPathName + ext;
        cache.setDestMd5(file, md5, md5Name, noPathName);
        if (isMd5) {
            if (isSource) return fs.outputFile(path.join(config.projectPath, config.packedAssetsPath, md5Name), buf);
            return fs.outputFile(path.join(config.projectPath, config.packedResPath, md5Name), buf);
        }
        if (isSource) return fs.outputFile(path.join(config.projectPath, config.packedAssetsPath, file), buf);
        return fs.outputFile(path.join(config.projectPath, config.packedResPath, file), buf);
    });

    function getMd5(buf) {
        var hash = crypto.createHash('md5');
        hash.update(buf);
        return hash.digest('hex');
    }
}

function packres(isMd5) {
    var uiResMap = resmanager.getUIResMap(true);
    var atlasMap = resmanager.getAtlasMap(true);
    var modelResMap = resmanager.getModelResMap();
    var resGroup = resmanager.getResGroup();
    if (!validateAtlas(atlasMap, resGroup))
        return Promise.reject(new Error('some resources missing in packed atlas'))
    var files = _.keys(uiResMap).filter(file => !atlasMap[file]);
    _.each(modelResMap, (_, file) => files.push(file));
    var startTime = new Date().getTime();
    let jsons = [];
    let others = [];
    files.forEach(temp => {
        if (temp.indexOf(".json") > -1 || temp.indexOf(".st") > -1 || temp.indexOf(".sk") > -1 || temp.indexOf(".atlas") > -1) jsons.push(temp);
        else others.push(temp);
    });
    var cache = new CacheManager();
    return cache.initWithFiles(files).then(() => {
        var totalCount = files.length;
        var bar = new ProgressBar(':bar', { total: totalCount, width: 50 });
        return new PromisePool(() => {
            if (others.length == 0)
                return null;
            var file = others.shift();
            return doTransform(file, cache, isMd5, true).then(() => bar.tick());
        }, 3).start();
    }).then(() => {
        return new PromisePool(() => {
            if (jsons.length == 0)
                return null;
            var file = jsons.shift();
            return doTransform(file, cache, isMd5, true);
        }, 3).start();
    }).then(() => {
        return copyOthers(cache, isMd5);
    }).then(() => {
        return cache.save(isMd5);
    })
}

module.exports = packres;

if (require.main == module) {
    packres();
}
