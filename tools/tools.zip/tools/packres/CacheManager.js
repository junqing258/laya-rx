var fs = require('fs-extra');
var path = require('path');
var glob = require('glob');
var PromisePool = require('es6-promise-pool');
var md5File = require('md5-file/promise');
var config = require('../config');
var _ = require('lodash');

function CacheManager() {
    this.rootPath = null;
    this.srcFiles = null;
    this.cachedMd5 = {}; // 从.cache.json中获取的已压缩的文件的md5
    this.sourceFilesMd5 = {}; // 原始文件的md5
    this.destFilesMd5 = {}; // 新的压缩的文件的md5
    this.md5Names = {};//存放MD5成生的文件名用于文件管理
    this.noPathMd5Names = {};;//存放MD5成生的没有路径的文件名用于文件管理
    this.untransformed = {}; // 是否进行过转换

    var cacheFile = path.join(config.projectPath, config.packedAssetsPath, '.cache.json');
    if (fs.existsSync(cacheFile)) {
        this.cachedMd5 = JSON.parse(fs.readFileSync(cacheFile, 'utf-8'));
    }

    var cachedNameFile = path.join(config.projectPath, config.packedAssetsPath, 'name.cache.json');
    if (fs.existsSync(cachedNameFile)) {
        this.cachedNameMd5 = JSON.parse(fs.readFileSync(cachedNameFile, 'utf-8'));
    }
}

// 清理目标目录，初始化缓存项，srcFiles为所有需要处理的源文件
CacheManager.prototype.initWithFiles = function (srcFiles, destPath) {
    if (!path.isAbsolute(destPath || (destPath = config.packedAssetsPath)))
        destPath = path.join(config.projectPath, destPath);//只有图片要配置JSON配置要路径换成res下
    this.rootPath = destPath;
    this.srcFiles = srcFiles.concat();
    var cacheFilesTemp = glob.sync('**/*', { cwd: this.rootPath, nodir: true, ignore: ['.cache.json', 'name.cache.json'] });
    var cacheFiles = [];
    var files = [];
    var tempName = "";
    cacheFilesTemp.forEach(fileTemp => {
        tempName = this.cachedNameMd5[fileTemp];
        if (tempName) {
            if (this.srcFiles.indexOf(tempName) == -1)
                files.push(fileTemp);
            else
                cacheFiles.push(tempName);
        }
        else {
            files.push(fileTemp);
        }
    });
    // var files = _.difference(cacheFiles, srcFiles); // 返回不在srcFiles中的文件
    _.pullAll(cacheFilesTemp, files); // 从cacheFiles清除files中包含的元素
    this.cachedMd5 = _.pick(this.cachedMd5, cacheFiles); // 清除cachedMd5中不存在的文件

    var concurrency = 20;
    return new PromisePool(() => {
        // 清除本次不需要操作的文件
        if (files.length == 0)
            return null;
        return fs.remove(path.join(this.rootPath, files.shift()));
    }, concurrency).start().then(() => {
        // 清除缓存中md5不配备的条目
        return new PromisePool(() => {
            if (cacheFilesTemp.length == 0)
                return null;
            var cachedMd5 = this.cachedMd5;
            var nameMd5 = this.cachedNameMd5;
            var file = cacheFilesTemp.shift();
            return md5File(path.join(destPath, file)).then(hash => {
                var tempName = nameMd5[file];
                var cache = this.cachedMd5[tempName];
                if (cache && cache.destMd5 && hash != cache.destMd5) {
                    delete this.cachedMd5[tempName];
                }
            })
        }, concurrency).start();
    })
}

CacheManager.prototype.setSourceMd5 = function (file, md5) {
    this.sourceFilesMd5[file] = md5;
}

CacheManager.prototype.getCacheInfo = function (file) {
    return this.cachedMd5[file];
}

CacheManager.prototype.getDestFilesMd5 = function (file) {
    return this.noPathMd5Names[file];
}

CacheManager.prototype.setDestMd5 = function (file, md5, md5Name, noPathFileName) {
    this.destFilesMd5[file] = md5;
    this.md5Names[file] = md5Name;
    this.noPathMd5Names[file] = noPathFileName;
}

CacheManager.prototype.setUnTransformed = function (file, untransformed) {
    untransformed && (this.untransformed[file] = untransformed);
}

CacheManager.prototype.useCache = function (file, srcMd5, isSkipTransform) {
    var cacheInfo = this.cachedMd5[file];
    this.setUnTransformed(file, isSkipTransform);
    if (!isSkipTransform && cacheInfo && cacheInfo.srcMd5 == srcMd5 && cacheInfo.destMd5 && !cacheInfo.untransformed) {
        this.setSourceMd5(file, cacheInfo.srcMd5);
        this.setDestMd5(file, cacheInfo.destMd5, cacheInfo.md5Name, cacheInfo.noPathFileName);
        return true;
    }
    return false;
}

CacheManager.prototype.save = function (isMd5) {
    var cachedMd5 = {};
    var verMd5 = {};
    var md5ToNames = {};
    for(let file in this.sourceFilesMd5) {
        var srcMd5 = this.sourceFilesMd5[file];
        var destMd5 = this.destFilesMd5[file];
        var md5Name = this.md5Names[file];
        var noPathFileName = this.noPathMd5Names[file];
        var untransformed = this.untransformed[file];
        if (srcMd5 && destMd5) {
            cachedMd5[file] = { srcMd5: srcMd5, destMd5: destMd5, md5Name: md5Name, noPathFileName: noPathFileName };
            if (untransformed)
                cachedMd5[file].untransformed = 1;
            var pngSource;
            if (file.indexOf(".json") > -1) {
                pngSource = file.replace(".json", ".png");
            }
            else if (file.indexOf(".st") > -1) {
                pngSource = file.replace(".st", ".png");
            }
            else if (file.indexOf(".atlas") > -1) {
                pngSource = file.replace(".atlas", ".png");
            }
            else if (file.indexOf(".sk") > -1) {
                pngSource = file.replace(".sk", ".png");
            }
            else verMd5[file] = noPathFileName;
            if(pngSource && !this.destFilesMd5[pngSource])  
                verMd5[file] = noPathFileName;
            md5ToNames[md5Name] = file;
        }
    }
    isMd5 && fs.outputFile(path.join(this.rootPath, 'versionsMd5.json'), JSON.stringify(verMd5, null, 4).replace(/\s*/g, ""));
    fs.outputFile(path.join(this.rootPath, 'name.cache.json'), JSON.stringify(md5ToNames, null, 4));
    return fs.outputFile(path.join(this.rootPath, '.cache.json'), JSON.stringify(cachedMd5, null, 4));
}

module.exports = CacheManager;
