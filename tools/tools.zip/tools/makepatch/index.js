var fs = require('fs-extra');
var path = require('path')
var _ = require('lodash');
var config = require('../config');
var execSync = require('child_process').execSync;
var glob = require('glob');
var gulputil = require('gulp-util');

function getResProjectPath() {
    var resPath = config.resourcePath;
    /*
    var stat = fs.lstatSync(resPath);
    if (!stat.isSymbolicLink()) {
        console.error('resource is not a symbol link');
        return;
    }
    resPath = fs.realpathSync(resPath);
    */
    return path.normalize(path.join(resPath, '..'));
}

function getResDiffFiles(patchBase) {
    if (!patchBase)
        return null;

    var resProjectPath = getResProjectPath();
    var resRegExp = new RegExp('^' + config.resourcePath);
    var cmd, output, tag, tagTime;
    try {
        if (/^\d{4}-\d{2}-\d{2}$/.test(patchBase)) {
            // 从指定日期往前1个月内的记录中，找最晚的一次提交
            var patchBaseTime = Date.parse(patchBase) - 8 * 3600 * 1000; // 去除时区差异
            var date1 = new Date(patchBaseTime - 3600 * 24 * 30 * 1000).toISOString()
            var date2 = new Date(patchBaseTime).toISOString();
            cmd = `git log --since="${date1}" --until="${date2}" --pretty=format:"%h"`;
            output = execSync(cmd, { cwd: resProjectPath, encoding: 'utf8' })
            tag = output.substr(0, output.indexOf('\n'));
        } else {
            cmd = `git show-branch ${patchBase}`;
            output = execSync(cmd, { cwd: resProjectPath, encoding: 'utf8' })
            tag = patchBase;
        }

        // 获取指定分支的时间cl
        cmd = `git log -1 --format=%ai ${tag}`
        output = execSync(cmd, { cwd: resProjectPath, encoding: 'utf8' })
        tagTime = output.replace('\n', '');

        gulputil.log(`基于${tag}，时间${tagTime}制作补丁`);
        cmd = `git log --name-only --pretty=oneline --full-index ${tag}..HEAD`
        output = execSync(cmd, { cwd: resProjectPath, encoding: 'utf8' });

        var files = output.split('\n').filter(str => {
            return (str.startsWith(config.resourcePath) && !str.startsWith(config.pagesPath))
             || str.match(/(libs).*\.js/g)
        });

        return _.uniq(files).map(str => str.startsWith(config.resourcePath)? str.replace(resRegExp, config.packedResPath) : str);
    } catch (err) {
        console.warn(err.message);
        return null;
    }
}

// srcPath, destPath均为版本的根目录
function copyResDiffs(srcPath, destPath, diffFiles) {
    //遍历packedResPath，只有在目录下的文件才拷贝
    var files = glob.sync(path.join(config.packedResPath, '**/*'), { cwd: srcPath })
    files = files.filter(file => !!diffFiles[file])
    files.forEach(file => {
        fs.copySync(path.join(srcPath, file), path.join(destPath, file));
        //gulputil.log("copySync " + path.join(srcPath,file) + "=>" + path.join(destPath,file));
    })

    //计算出有图片变化的图集名称
    var sheetsMap = {};
    for(let v in diffFiles) {
        if(!diffFiles[v] && v.startsWith(config.packedAssetsPath)) {
            let sheetFile = v.replace(config.packedAssetsPath + '/', '');
            sheetFile = sheetFile.substring(0,sheetFile.indexOf("/"));
            sheetsMap[sheetFile] = (sheetsMap[sheetFile] || 0) + 1;
        }
    }

    //拷贝图集内图片有更新变化的图集st和png文件
    var sheetCount = 0;
    var sheetsFiles = glob.sync(path.join(config.packedAssetsPath, 'sheets/*'), { cwd: srcPath });
    sheetsFiles.forEach(file => {
        let sheetFile = file.replace(config.packedAssetsPath + '/sheets/','');
        sheetFile = sheetFile.substring(0,sheetFile.indexOf('.'));
        if(sheetsMap[sheetFile]) {
            diffFiles[file] = true;
            fs.copySync(path.join(srcPath, file), path.join(destPath, file));
            //gulputil.log("copySync " + path.join(srcPath,file) + "=>" + path.join(destPath,file));
            sheetCount++;
        }
    });
    return files.length + sheetCount;
}

function zipFilesForPatch(destPath) {
    gulputil.log('开始压缩增量版本...');
    return new Promise((resolve, reject) => {
        let archive = require('archiver')('zip');
        let fileName = path.basename(destPath) + '.zip';
        
        let outFilePath = path.join(path.dirname(destPath), fileName);
        let output = fs.createWriteStream(outFilePath);
        output.on('close', () => {
            gulputil.log('压缩增量版本成功,压缩文件为: ' + outFilePath);
            resolve(outFilePath)
        });
        archive.on('error', err => reject(err));
        archive.pipe(output);
        archive.directory(path.join(destPath,config.packedAssetsPath),config.packedAssetsPath); //res
        archive.file(path.join(destPath,'index.html'),{name:'index.html'});
        archive.directory(path.join(destPath,"bin"),"bin"); //bin/js/game.js
        archive.directory(path.join(destPath,"libs"),"libs"); //libs
        archive.finalize();
    })
}

function zipFilesForDolphin(zipPath) {
    gulputil.log('开始压缩为GCloud Dolphin资源更新文件...');
    return new Promise((resolve, reject) => {
        let archive = require('archiver')('zip');
        let fileName = path.basename(zipPath);
        
        let outFilePath = path.join(path.dirname(zipPath), 'dolphin-' + fileName);
        let output = fs.createWriteStream(outFilePath);
        output.on('close', () => {
            gulputil.log('压缩Dolphin资源更新文件成功,压缩文件为: ' + outFilePath);
            resolve(outFilePath)
        });
        archive.on('error', err => reject(err));
        archive.pipe(output);
        archive.file(zipPath,{name: "patch/"+fileName});
        archive.finalize();
    })
}


function makePatch(srcPath, patchBase, zip) {
    if(!srcPath || srcPath.length == 0) {
        gulputil.log('-path 路径 指定本次全量版本的路径');
        return;
    }
    if(!patchBase || patchBase.length == 0) {
        gulputil.log('-patchbase 指定补丁制作的基准版本的发布日期或基准版本的git标签');
        return;
    }
    gulputil.log('开始制作增量版本...')
    var startTime = Date.now();
    
    if(!config.patchPath) config.patchPath = "patch";
    var patchPath = path.basename(srcPath) + '-patch-' + patchBase;
    var destPath = path.join(config.patchPath, patchPath);
    fs.emptyDirSync(destPath);

    // 拷贝资源的增量文件
    var diffFiles = getResDiffFiles(patchBase);

    var jscount = 0;
    var count = 0;
    var diffFilesMap = {};
    if (_.isEmpty(diffFiles)) {
        console.warn('没有发现新的增量资源文件')
    } else {
        var md5File = path.join(config.packedAssetsPath, '.cache.json');
        let fileMd5Map = fs.readJSONSync(md5File, 'utf-8');

        diffFilesMap = _.transform(diffFiles, (result, v, k) => {
            if (v.startsWith(config.packedAssetsPath)) { //res的文件，需要在索引里面存在
                let md5V = v.replace(config.packedAssetsPath + '/', '');
                result[v] = !!fileMd5Map[md5V];
            }
            else
                result[v] = true;
        },{});
        count = copyResDiffs(srcPath, destPath, diffFilesMap);
    }

    //复制.cache.json
    //拷贝index.html文件
    var cacheJsonFile = path.join(config.packedAssetsPath, '.cache.json');
    var files = ['index.html', cacheJsonFile];
    files.forEach(file => {
        diffFilesMap[file] = true;
        fs.copySync(path.join(srcPath,file), path.join(destPath, file));
        //gulputil.log("copySync " + path.join(srcPath,file) + "=>" + path.join(destPath,file));
        jscount++;
    });

    //拷贝game.js和其他js文件
    var content = fs.readFileSync(path.join(srcPath,'index.html'), 'utf8');
    var matches = content.match(/src\s*=\s*"(libs|bin).*\.js/g)
    files = matches.map(file => file.substr(file.indexOf('"') + 1))
    files.forEach(file => {
        if(file.startsWith("libs")) {
            if(diffFilesMap[file]) {
                fs.copySync(path.join(srcPath,file), path.join(destPath, file));
                //gulputil.log("copySync " + path.join(srcPath,file) + "=>" + path.join(destPath,file));
                jscount++;
            }
        }
        else {
            diffFilesMap[file] = true;
            fs.copySync(path.join(srcPath,file), path.join(destPath, file));
            //gulputil.log("copySync " + path.join(srcPath,file) + "=>" + path.join(destPath,file));
            jscount++;
        }
    });

    gulputil.log(diffFilesMap);
    fs.outputFile(path.join(destPath, '.diffFiles.json'), JSON.stringify(diffFilesMap, null, 4));

    var timeDiff = (Date.now() - startTime) / 1000;
    gulputil.log(`增量版本制作完成:${patchPath}, 资源文件增量:${count}, 其他文件增量:${jscount}, 耗时: ${timeDiff}秒`)

    if(zip) { //如果带zip参数同时生成zip文件
        zipFilesForPatch(destPath).then((zipPath) => {
            zipFilesForDolphin(zipPath)
        })
    }
}

module.exports = makePatch;

if (require.main == module) {
    var argv = require('yargs').help('h')
        .option('path', { alias: 'p', describe: '指定本次全量版本的路径' })
        .option('patchbase', { alias: 'b', describe: '指定补丁制作的基准版本的发布日期或基准版本的git标签' })
        .option('zip', { alias: 'z', describe: '压缩发布文件' })
        .demand(['path', 'patchbase'])
        .argv;
    makePatch(path.normalize(argv.path), argv.patchbase, argv.zip);
}
