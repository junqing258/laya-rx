/**
 * 生成各个模型的宽高，并输出到src/gen/modelSize.ts中
 */

var fs = require('fs-extra');
var path = require('path');
var glob = require('glob');
var PromisePool = require('es6-promise-pool');
var config = require('../config');
var PNG = require('pngjs').PNG;

var modelBasePath = path.join(config.projectPath, config.assetsPath, 'fight.d');

function isSolidPixel(image, x, y) {
    var idx = (image.width * y + x) << 2;
    return image.data[idx + 3] == 255 && image.data[idx] > 0 && image.data[idx+1] > 0 && image.data[idx+2] > 0;
}

// 获取json文件中第一帧对应的图片位置的描述数据，并附加上中心点的偏移数据
function getFirstFrameData(jsonFile) {
    var jsonData = JSON.parse(fs.readFileSync(jsonFile))
    var firstFrame;
    for (var key in jsonData.mc) {
        var frames = jsonData.mc[key].frames;
        firstFrame = frames[0];
        break
    }
    var data = jsonData.res[firstFrame.res];
    data.offsetX = firstFrame.x;
    data.offsetY = firstFrame.y;
    return data;
}

function getModelSize(modelType, modelName) {
    return new Promise((resolve, reject) => {
        var loadFile = '4_stand.png';
        if(modelType == "npc")
            loadFile = '3_stand.png';
        var imageFile = path.join(modelBasePath, modelType, modelName, loadFile);
        var extName = path.extname(imageFile);
        var jsonFile = imageFile.substr(0, imageFile.length - extName.length) + '.json';
        if (!fs.existsSync(imageFile) || !fs.existsSync(jsonFile)) {
            var err = new Error(`${modelType}/${modelName} not exists`)
            console.error(err.message);
            reject(err);
            return;
        }

        var frameData = getFirstFrameData(jsonFile)
        fs.createReadStream(imageFile).pipe((new PNG({filterType: 4}))).on('parsed', function() {
            //resolve({type: modelType, name: modelName, width: frameData.w, height: frameData.h});
            // 计算基准点的坐标
            var pivotX = frameData.x - Math.round(frameData.offsetX);
            var pivotY = frameData.y - Math.round(frameData.offsetY);
            var width, height;
            // 提取高度
            for (var y = frameData.y; y < pivotY; y++) {
                if (isSolidPixel(this, pivotX, y)) {
                    height = pivotY - y;
                    break;
                }
            }
            // 横向提取图片左边及右边到中心点的第一个非透明像素位置
            var left1 = pivotX, left2 = pivotX;
            for (var x = frameData.x; x < pivotX; x++) {
                if (isSolidPixel(this, x, pivotY)) {
                    left1 = x;
                    break;
                }
            }
            for (var x = frameData.x + frameData.w; x > pivotX; x--) {
                if (isSolidPixel(this, x, pivotY)) {
                    left2 = x;
                    break;
                }
            }
            //width = Math.max(pivotX - left1, left2 - pivotX) * 2;
            width = frameData.w;
            resolve({type: modelType, name: modelName, width: width+10, height: height}); // 宽度增加10像素误差
        })
    })
}

function genModelSize() {
    var modelTypes = ['monster', 'role', 'hero', 'npc'];
    var modelDatas = {};
    var tasks = [];
    modelTypes.forEach(type => {
        if (!modelDatas[type]) modelDatas[type] = {};
        var modelTypePath = path.join(modelBasePath, type);
        var modelNames = glob.sync('*', {cwd: modelTypePath})
        modelNames.forEach(name => tasks.push({type: type, name: name}));
    })

    return new PromisePool(() => {
        if (tasks.length == 0)
            return null;
        var task = tasks.shift();
        return getModelSize(task.type, task.name).then(data => {
            modelDatas[task.type][task.name] = [data.width, data.height];
        });
    }, 20).start().then(() => {
        return modelDatas;
    });
}

function getFrameRate(type, name, motionFile) {
    return fs.readFile(filePath).then()
}

function genFrameRates() {
    var modelTypes = ['monster', 'role', 'hero', 'npc'];
    var frameDatas = {};
    var tasks = [];
    modelTypes.forEach(type => {
        if (!frameDatas[type]) frameDatas[type] = {};
        var modelTypePath = path.join(modelBasePath, type);
        var modelNames = glob.sync('*', {cwd: modelTypePath})
        modelNames.forEach(name => {
            if (!frameDatas[type][name]) frameDatas[type][name] = {};
            var modelMotionPath = path.join(modelTypePath, name);
            var motionFiles = glob.sync('*.json', {cwd: modelMotionPath});
            motionFiles.forEach(motionFile => {
                tasks.push({type: type, name: name, motionFile: motionFile});
            })
        });
    });
    return new PromisePool(() => {
        if (tasks.length == 0)
            return null;
        var task = tasks.shift();
        var filePath = path.join(modelBasePath, task.type, task.name, task.motionFile);
        return fs.readFile(filePath).then(content => {
            var data = JSON.parse(content);
            if (data.mc) {
                for (var key in data.mc) {
                    var frameData = data.mc[key];
                    var motion = task.motionFile.replace(/\d*_?(.*)\.json/, '$1');
                    frameDatas[task.type][task.name][motion] = [frameData.frames.length, frameData.frameRate];
                    break;
                }
            }
        })
    }, 20).start().then(() => {
        return frameDatas;
    })
}

function genModel() {
    Promise.all([
        genModelSize(),
        genFrameRates()
    ]).then(data => {
        fs.writeFileSync(path.join(config.projectPath, config.codeGenPath, 'modelSize.ts'),
`namespace app.fight {
export var ModelSize = ${JSON.stringify(data[0], null, 4)};
export var ModelFrame = ${JSON.stringify(data[1], null, 4)};
}`
        );
        fs.writeFileSync(path.join(config.projectPath, config.codeGenPath, 'modelsize.json'),JSON.stringify(data[0], null, 4))
    }).catch(e => console.log(e));
}

module.exports = genModel;

if (require.main == module) {
    genModel();
}
