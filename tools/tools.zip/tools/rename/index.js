var glob = require('glob');
var fs = require('fs-extra');
var path = require('path');

function rename(dir) {
    var files = glob.sync(path.join(dir, '**/**'), null);
    var replaceList = { "A": 0, "B": 1, "C": 2, "D": 3, "E": 4 };
    files.forEach(file => {
        var ext = path.extname(file);
        var needRename = ext == '.png' || ext == '.json';
        if (needRename) {
            var basename = path.basename(file);
            var dirname = path.dirname(file);
            let baseArr = basename.split('.');
            let frontBase = baseArr[0];
            let newBase = replaceList[frontBase];
            if (newBase == undefined) {
                console.log("erro.....", file);
                return;
            }
            newBase += ext;
            var newPath = dirname + "/" + newBase;
            console.log("newPath.....", newPath);
            fs.rename(file, newPath);
        }
    });
}

module.exports = rename;

if (require.main == module) {
    let dir = "/Users/admin/workSpace/mu/client/laya/assets/fight.d/effect";
    rename(dir);
}
