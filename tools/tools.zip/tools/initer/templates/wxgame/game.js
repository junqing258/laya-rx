require("weapp-adapter.js");
window.Parser = require("./js/dom_parser");
require("code.js");
