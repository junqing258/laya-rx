var config = {
    host: '',
    channel: 'HOODINN',
}
