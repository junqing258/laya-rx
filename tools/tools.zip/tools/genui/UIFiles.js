var glob = require('glob');
var fs = require('fs-extra');
var path = require('path');
var config = require('../config');
var UIFile = require('./UIFile');
var _ = require('lodash');

function UIFiles() {
    this.parsedFiles = {};
    this.parsedFilesByClass = {};
}

UIFiles.prototype.parse = function() {
    var files = glob.sync('**/*.ui', {cwd: config.pagesPath});
    _.each(files, file => {
        if (this.parsedFiles[file])
            return;
        var uifile = new UIFile();
        uifile.parse(file);
        this.parsedFiles[file] = uifile;
    });
    _.each(this.parsedFiles, uifile => {
        uifile.postProcess(this);
    });
}

UIFiles.prototype.getUIFile = function(path) {
    return this.parsedFiles[path];
}

UIFiles.prototype.getUIFileByClass = function(className) {
    return this.parsedFilesByClass[className];
}

module.exports = UIFiles;
