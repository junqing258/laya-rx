var glob = require('glob');
var fs = require('fs-extra');
var path = require('path');
var helper = require('./helper');
var UIFile = require('./UIFile');
var UIFiles = require('./UIFiles');
var dust = require('dustjs-helpers');
var config = require('../config');
var settings = require(path.join(config.projectPath, config.settingsFile));
var resmanager = require('../resmanager');
var _ = require('lodash');
require('./templates');

function genui() {
    var uifiles = new UIFiles();
    uifiles.parse();

    var viewMap = {};
    _.each(uifiles.parsedFiles, uifile => _.each(uifile.viewMap, (_, view) => viewMap[view] = view));

    var data = {
        uifiles: _.values(uifiles.parsedFiles),
        viewMap: viewMap,
        fontMap: resmanager.getFontMap(),
        settings: settings,
    }
    dust.render('all', data, function (err, out) {
        if (err) return console.log(err);
        fs.outputFileSync(config.uiCodeFile, out);
    });

    // require('./msgcreate')();

    return Promise.resolve();
}

module.exports = genui;

if (require.main == module) {
    genui();
}
